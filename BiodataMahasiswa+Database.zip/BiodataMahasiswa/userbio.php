<?php
    
    $koneksi=mysqli_connect("localhost","root","","biodata");

?>



<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title>Biodata Mahasiswa</title>
    <style>
h1 {text-align: center;}
p {text-align: center;}
div {text-align: center;}
</style>
<img src="assets/img/polinema.png" class="user-image img-responsive"/>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
   <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
</head>

</button>
               
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 12px;">  &nbsp; <a href="logout.php" class="btn btn-danger square-btn-adjust">Logout</a> </div>
       
					</li>

<div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             BIODATA MAHASISWA 
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>NO</th>
                                            <th>NIM</th>
                                            <th>NAMA</th>
                                            <th>AGAMA</th>
                                            <th>PROGRAM STUDY</th>
                                            <th>KELAS</th>
                                            <th>KOTA ASAL</th>
                                          
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php

                                        $no = 1;

                                       $sql =mysqli_query($koneksi,"select * from biodata_mahasiswa");

                                            while ($data= mysqli_fetch_array($sql)) {
                                                                                          

                                        ?>

                                       
                                          <tr>
                                            <td><?php echo $no++;?></td>                                        
                                            <td><?php echo $data ['A'];?></td>
                                            <td><?php echo $data ['B'];?></td>
                                            <td><?php echo $data ['C'];?></td>
                                            <td><?php echo $data ['D'];?></td>
                                            <td><?php echo $data ['E'];?></td>
                                            <td><?php echo $data ['F'];?></td>
                                            

                                    <?php } ?>

                                    </tbody>
