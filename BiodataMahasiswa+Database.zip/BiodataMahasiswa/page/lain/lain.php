$simpan = $_POST ['simpan'];

	if ($simpan){

		  $sql =mysql_query($koneksi,"INSERT INTO  biodata_mahasiswa ('A','B','C','D','E','F') VALUES('$A','$B','$C','$D','$D','$E','$F')");


		   value="<?php echo $data['B'];?>"