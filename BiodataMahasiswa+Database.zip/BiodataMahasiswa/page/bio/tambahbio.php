                                          

<div class="panel panel-default">
<div class="panel-heading">
	TAMBAH  DATA
</div>

<div class="panel-body">
                            <div class="row">
                                <div class="col-md-6">

                                	<form method="POST">                                   
                                        <div class="form-group">
                                            <label>NIM</label>
                                            <input class="form-control"name="A" />                                  
                                        </div>


                                        <div class="form-group">
                                            <label>NAMA</label>
                                            <input class="form-control"name="B" />                 
                                    </div>

                                  	    <div class="form-group">
                                            <label>AGAMA</label>
                                            <input class="form-control"name="C" /> 


                                    <div class="form-group">
                                            <label>PROGRAM STUDY</label>
                                            <input class="form-control"name="D" />                                  
                                 </div>

                                 <div class="form-group">
                                            <label>KELAS</label>
                                            <input class="form-control"name="E" />                                  
                                 </div>

                                 
                                 <div class="form-group">
                                            <label>KOTA ASAL</label>
                                            <input class="form-control"name="F" />                                  
                                 </div>


                                 <div>

                                 	<input type="submit" name ="simpan" value="simpan" class="btn btn-primary">

                                 	</div>
							</div>

						</form>
					</div>


</div>
</div>




<?php
	$A3=$_POST ['A'];
	$B3=$_POST ['B'];
	$C3=$_POST ['C'];
	$D3=$_POST ['D'];
	$E3=$_POST ['E'];
	$F3=$_POST ['F'];

	$simpan = $_POST ['simpan'];


    if ($simpan){

         $sql =mysqli_query($koneksi,"INSERT INTO biodata_mahasiswa VALUES ('$A3','$B3','$C3','$D3','$E3','$F3')");
                   
		if ($sql) {

			?>

			<script type="text/javascript">
				
				alert ("Data Berhasil DITAMBAHKAN ")
				window.location.href="?page=bio";

			</script>

			<?php
		}

	}
?>