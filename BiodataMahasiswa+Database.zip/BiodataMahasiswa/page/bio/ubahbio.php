<?php 

	$id	=$_GET[id];

	$sql =mysqli_query($koneksi,"SELECT * from biodata_mahasiswa WHERE A='$id'");

    $data = mysqli_fetch_array($sql);
                                        ?>                           
                                         
                                  



<div class="panel panel-default">
<div class="panel-heading">
	UBAH DATA
</div>
<div class="panel-body">
                            <div class="row">
                                <div class="col-md-6">

                                	<form method="POST">                                   
                                        <div class="form-group">
                                            <label>NIM</label>
                                            <input class="form-control"name="A"  value="<?php echo $data['A'];?>" readonly/>                                  
                                        </div>


                                        <div class="form-group">
                                            <label>NAMA</label>
                                            <input class="form-control"name="B" value="<?php echo $data['B'];?>" />                 
                                    </div>

                                  	    <div class="form-group">
                                            <label>AGAMA</label>
                                            <input class="form-control"name="C" value="<?php echo $data['C'];?>" /> 


                                    <div class="form-group">
                                            <label>PROGRAM STUDY</label>
                                            <input class="form-control"name="D" value="<?php echo $data['D'];?>" />                                  
                                 </div>

                                 <div class="form-group">
                                            <label>KELAS</label>
                                            <input class="form-control"name="E" value="<?php echo $data['E'];?>" />                                  
                                 </div>

                                 
                                 <div class="form-group">
                                            <label>KOTA ASAL</label>
                                            <input class="form-control"name="F" value="<?php echo $data['F'];?>" />                                  
                                 </div>


                                 <div>

                                 	<input type="submit" name ="simpan" value="simpan" class="btn btn-primary">

                                 	</div>
							</div>

						</form>
					</div>


</div>
</div>




<?php
	$A2=$_POST ['A'];
	$B2=$_POST ['B'];
	$C2=$_POST ['C'];
	$D2=$_POST ['D'];
	$E2=$_POST ['E'];
	$F2=$_POST ['F'];

	$simpan = $_POST ['simpan'];

	if ($simpan){

		  $sql =mysqli_query($koneksi,"UPDATE  biodata_mahasiswa SET B='$B2',C='$C2',D='$D2',E='$E2',F='$F2'  WHERE  A='$A2'" );


                   
		if ($sql) {

			?>
			<script type="text/javascript">
				
				alert ("Data Berhasil Diubah")
				window.location.href="?page=bio";

			</script>
			<?php
		}
	}
?>