<?php
    
    $koneksi=mysqli_connect("localhost","root","","biodata");

?>



<a href="?page=bio&aksi=tambahbio" class="btn btn-primary" style="margin-bottom: 10px;">Tambah Data


</a>



<div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             BIODATA MAHASISWA 
 <style>
h1 {text-align: center;}
p {text-align: center;}
div {text-align: center;}
</style>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    
                                    <thead>
                                        <tr>
                                            <th>NO</th>
                                            <th>NIM</th>
                                            <th>NAMA</th>
                                            <th>AGAMA</th>
                                            <th>PROGRAM STUDY</th>
                                            <th>KELAS</th>
                                            <th>KOTA ASAL</th>
                                            <th>KETERANGAN</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php

                                        $no = 1;

                                       $sql =mysqli_query($koneksi,"select * from biodata_mahasiswa");

                                            while ($data= mysqli_fetch_array($sql)) {
                                                                                          

                                        ?>

                                       
                                          <tr>
                                            <td><?php echo $no++;?></td>                                        
                                            <td><?php echo $data ['A'];?></td>
                                            <td><?php echo $data ['B'];?></td>
                                            <td><?php echo $data ['C'];?></td>
                                            <td><?php echo $data ['D'];?></td>
                                            <td><?php echo $data ['E'];?></td>
                                            <td><?php echo $data ['F'];?></td>
                                            <td>
                                                <a href="?page=bio&aksi=ubahbio&id=<?php echo $data['A'];?> " class="btn btn-info">Ubah</a>
                                                <a href="?page=bio&aksi=hapus&id=<?php echo $data['A'];?> " class="btn btn-danger">Hapus</a>
                                            </td>
                                        </tr>

                                    <?php } ?>

                                    </tbody>
