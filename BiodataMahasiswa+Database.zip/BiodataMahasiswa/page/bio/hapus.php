<?php 
	$id	=$_GET[id];

	  $sql =mysqli_query($koneksi,"DELETE FROM biodata_mahasiswa  WHERE  A='$id'" );


                   
		if ($sql) {
		?>

			<script type="text/javascript">
				
				alert ("Data Berhasil Dihapus")
				window.location.href="?page=bio";

		
			</script>
			<?php
		}
	
?>
